//
//  LoginViewController.swift
//  EmployeeSystem
//
//  Created by MacStudent on 2018-08-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    
    @IBOutlet weak var txtEmailid: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnlogin(_ sender: Any) {
        
        if (txtEmailid.text == "jass194@gmail.com" && txtPassword.text == "jass")
        {
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let tableView = storyBoard.instantiateViewController(withIdentifier: "TableView") as! TableViewController
            self.present(tableView, animated: true, completion: nil)
            
        }else
        {
            let myAlert = UIAlertController(title: "Alert", message: "Invalid User", preferredStyle: UIAlertControllerStyle.alert)
            let okAction = UIAlertAction(title: "ok", style: UIAlertActionStyle.default, handler: nil)
            myAlert.addAction(okAction)
            self.present(myAlert,animated: true, completion: nil)
            
        }
    }
    
   
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
